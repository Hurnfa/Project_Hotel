/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;
/**
 *
 * @author Advice
 */
public class tables {
       public static void main (String[] arge) {
       
           Connection con = null;
           Statement st = null;
           
           try
           {
               con=ConnectionProvider.getCon();
               st=con.createStatement();
               st.executeUpdate("create table users(name varchar(200),email varchar(200),password varchar(50), securityQuestion varchar(500), answer varchar(200),address varchar(200),status varchar(20))");
               st.executeUpdate("create table room(RoomNo varchar(10), RoomType varchar (200), Bed varchar(200), price int,status varchar(20))");
                 st.executeUpdate("create table customer(Id int, Name varchar(200),MobilePhone varchar(15),Nationality varchar (15), Gender varchar (20), Email varchar (50), IdProof varchar (50), Address varchar (200), Checkin varchar (50),RoomNo varchar(10), Bed varchar (30), RoomType varchar(200), PriceperDay int(10), NumberOfDaysStay int(5), TotalAmount varchar(50), Checkout varchar(50))");                   
             JOptionPane.showMessageDialog(null, "Table created Successfully");
           
           
           }
           catch(Exception e)
           {
               JOptionPane.showMessageDialog(null,e);
           }
           finally
           {
                try
           {
               con.close();
               st.close();
               
           }
           catch(Exception e)
           {
           }
           
           }    
           
           
                
       }
}
